
const AuthService = {
    isAuth: function () {
        var t = this.getToken();
        var f = (typeof (t) == "undefined" || t == null);
        return !f;
    },
    setToken(userToken) {
        localStorage.setItem('token', JSON.stringify(userToken));
    },
    getToken() {
        const tokenString = localStorage.getItem('token');
        const userToken = JSON.parse(tokenString);
        return userToken;
    },
    loginUser(credentials) {
        return new Promise((resolve, reject) => {

            fetch('https://reqres.in/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(credentials)
            })
                .then(data => data.json())
                .then(
                    (result) => {
                        console.log(result)
                        this.setToken("QpwL5tke4Pnpja7X4");
                        resolve(true);

                    },
                    (error) => {
                        console.log(error)
                        reject(false);

                    }
                );

        })
    },
    logOut: function () {

        localStorage.removeItem('token');
        localStorage.clear();
        return true;
    }
};
export default AuthService;
