import { withRouter } from "react-router";

const LogoutButton = withRouter(({ history }) => {
    return (
        <button onClick={() => history.push("/login")}>
            Logout
        </button>
    );
});

export default LogoutButton;