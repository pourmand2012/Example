import { useHistory } from "react-router-dom";
import AuthService from '../src/Service';

function HomeButton() {
    const history = useHistory();

    function handleClick() {
        debugger;
        AuthService.logOut();
        // localStorage.removeItem("token")
        // localStorage.clear()
        history.push("/login")
    }

    return (
        <button type="button" onClick={(e) => handleClick()}>
            Login
        </button>
    );
}
export default HomeButton