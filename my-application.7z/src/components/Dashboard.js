import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Route, Switch, Link } from 'react-router-dom';
import Login from '../components/login';
import AuthService from '../Service';
import React from 'react';
import Listuser from './listUser'
import { Redirect } from "react-router-dom";
import UserInfo from './usetInfo';

class Dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.state = { redirect: !AuthService.isAuth() };
    }

    logout() {
        AuthService.logOut();
        this.setState({ redirect: true })
    }
    render() {

        if (this.state.redirect) {
            return <Redirect to="Login" />
        }
        else

            return (
                <div className="d-flex" id="wrapper">

                    <BrowserRouter>
                        <div className="bg-light border-right" id="sidebar-wrapper">
                            <div className="sidebar-heading">Start Bootstrap</div>
                            <div className="list-group list-group-flush">
                                <span className="list-group-item list-group-item-action bg-light" >
                                    <Link to="/listuser">لیست کاربران</Link>
                                </span>
                            </div>
                        </div>

                        <div id="page-content-wrapper">
                            <nav className="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                                <button className="navbar-toggler" type="button" data-toggle="collapse"
                                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                                    aria-label="Toggle navigation"><span className="navbar-toggler-icon"></span></button>
                                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul className="navbar-nav ml-auto mt-2 mt-lg-0">
                                        <li className="nav-item active">
                                            <a className="nav-link" href="#!" onClick={(e) => this.logout()}>
                                                LogOut
                                    <span className="sr-only">(current)</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </nav>
                            <div className="container-fluid">
                                <Switch>
                                    <Route path="/listuser">
                                        <Listuser />
                                    </Route>
                                    <Route path="/userInfo"
                                        render={(props) => <UserInfo option={props.history.location.state} />} />

                                </Switch>
                            </div>
                        </div>

                    </BrowserRouter>
                </div>


            )
    }
}



export default Dashboard

