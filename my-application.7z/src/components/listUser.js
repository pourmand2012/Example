import React from 'react';
import { Redirect } from "react-router-dom";

class Listuser extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [],
            infoUserId: 0
        }
        this.getdata();
        this.infoUser = this.infoUser.bind(this);
    }
    infoUser(item) {
        this.setState({ 'infoUserId': item.id });
    }
    getdata() {
        fetch('https://reqres.in/api/users?page=2', {
            headers: {
                'Content-Type': 'application/json'
            },
        })
            .then(data => data.json())
            .then(
                (result) => {
                    this.setState({ "data": result.data });
                    // console.log(result.data)
                    console.log(this.state)
                },
                (error) => {
                    console.log(error)
                }
            );
    }

    render() {
        if (this.state.infoUserId != 0) {
            return <Redirect
                to={{
                    pathname: "/userInfo",
                    state: { property_id: this.state.infoUserId }
                }}
            />

        }
        return (<div>
            <table className="table">
                <thead>
                    <tr>
                        <th scope="col">first_name</th>
                        <th scope="col">last_name</th>
                        <th scope="col">email</th>
                        <th scope="col"></th>
                    </tr>
                </thead>

                <tbody>

                    {
                        this.state.data
                            .map((row, index) => {
                                return (
                                    <tr key={row.id}>
                                        <td>{row.first_name}</td>
                                        <td>{row.last_name}</td>
                                        <td>{row.email}</td>
                                        <td>
                                            <button type="button"
                                                onClick={(e) => { this.infoUser(row, e) }}
                                                className="btn btn-outline-success btn-sm btn-add">
                                                <i className="fa fa-info"></i>
                                            </button>
                                        </td>

                                    </tr>
                                )
                            })
                    }
                </tbody>
            </table>
        </div >);
    }
}
export default Listuser

