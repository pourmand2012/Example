import React from 'react';
import Loading from './loading'
class UserInfo extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            id: this.props.option.property_id,
            user: null
        }
        this.getdata(this.state.id);
    }

    getdata(id) {
        fetch('https://reqres.in/api/users/' + id, {
            headers: {
                'Content-Type': 'application/json'
            },
        })
            .then(data => data.json())
            .then(
                (result) => {
                    this.setState({ "user": result.data });
                    // console.log(result.data)
                    console.log(this.state)
                },
                (error) => {
                    console.log(error)
                }
            );
    }

    render() {

        if (this.state.user === null)
            return <Loading />
        return (<div className="card imgavatar">

            <img className="card-img-top" src={this.state.user.avatar} alt="Card image cap"></img>
            <div className="card-body">
                <h5 className="card-title">{this.state.user.last_name}</h5>
                <p className="card-text">{this.state.user.first_name}</p>
                <a href="#" className="btn btn-primary">Go somewhere</a>
            </div>
        </div>
        )
    }
}

export default UserInfo
