import 'bootstrap/dist/css/bootstrap.min.css';

import Dashboard from '../src/components/Dashboard';
import Login from '../src/components/login';
import { BrowserRouter, Route, Switch, Link } from 'react-router-dom';

import React from 'react';
function App() {
  return (
    <div className="wrapper">
      <BrowserRouter>
        <Switch>
          <Route path="/dashboard">
            <Dashboard />
          </Route>
          <Route path="/">
            <Login />
          </Route>
        </Switch>
      </BrowserRouter>
    </div>
  );
}



export default App;
